const { Builder, By, Key, until } = require("selenium-webdriver");
const testCases = require("./test");
const fs = require("fs");
const testSuite = require("./testCase.json");

const driver = new Builder().forBrowser("chrome").build();

async function browserNavigation(action) {
  switch (action) {
    case "back":
      await driver.navigate().back();
      break;
    case "forward":
      await driver.navigate().forward();
      break;
    case "refresh":
      await driver.navigate().refresh();
      break;
    default:
      console.error("The action is not correct, please check your action");
      break;
  }
}

async function alertsHandler(action, text = "") {
  await driver.wait(until.alertIsPresent());
  let alert = await driver.switchTo().alert();
  switch (action) {
    case "accept":
      await alert.accept();
      break;
    case "dismiss":
      await alert.dismiss();
      break;
    case "submit":
      await alert.sendKeys(text);
      await alert.accept();
      break;
    default:
      console.error("The action is not correct, please check your action");
      break;
  }
}

async function windowHandler(action, data = "") {
  const windows = await driver.getAllWindowHandles();
  switch (action) {
    case "minimize":
      await driver.manage().window().minimize();
      break;
    case "maximize":
      await driver.manage().window().maximize();
      break;
    case "fullScreen":
      await driver.manage().window().fullscreen();
      break;
    case "switchWindow":
      await driver.switchTo().window(windows[1]);
      break;
    case "switchBack":
      await driver.switchTo().window(windows[0]);
      break;
    case "takeScreenShot":
      let encodedString = await driver.takeScreenshot();
      fs.writeFileSync(`./images/${data}.png`, encodedString, "base64");
      break;
    case "time":
      await driver.sleep(data * 1000);
      break;
    case "quite":
      await driver.quit();
      break;
    default:
      console.error("The action is not correct, please check your action");
      break;
  }
}

async function actionFunction(action = "", xpath = "", text = "") {
  switch (action) {
    case "get":
      await driver.get(text);
      break;
    case "click":
      await driver.findElement(By.xpath(xpath)).click;
      break;
    case "input":
      await driver.findElement(By.xpath(xpath)).sendKeys(text);
      break;
    default:
      console.error("The action is not correct, please check your action");
      break;
  }
}

async function mainFunction(script) {
  console.log("scriptscript", script);
  try {
    script.forEach(async (step) => {
      switch (true) {
        case step.beforeSleep > 0:
          console.log("SLEEP====>>", step.beforeSleep);
          await windowHandler("sleep", step.beforeSleep);
        case step.screenshot:
          console.log("SCREENSHOT====>>", step.screenshot);
          await windowHandler("takeScreenShot", step.screenshot);
        case step.windowZoom:
          console.log("WINDOWZOOM====>>", step.windowZoom);
          await windowHandler("maximize");
        case step.refreshWindow:
          console.log("REFRESHWINDOW====>>", step.refreshWindow);
          await browserNavigation("refresh");
        default:
          await actionFunction(
            step.action.toLowerCase(),
            step.xpath,
            step.addText
          );
          await driver.quit();
          break;
      }
    });
  } catch (error) {
    console.log("error ===>", error);
  }
}

mainFunction(testSuite[0].testSteps);
